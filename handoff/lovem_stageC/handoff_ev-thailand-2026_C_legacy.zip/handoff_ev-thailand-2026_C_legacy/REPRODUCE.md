# 再実行の手順（LOVEM 段階 A の run フォルダ）

- run_id：`ev-thailand-2026@3481fc5:obs`
- code_sha：`3481fc5b30ba88f8bb445d1ced888212b3221591`（dirty=False、dirty_diff_hash=`e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`、対象 `wom` `tools` `data`）
- モデル：`data/sample/ev-thailand-2026`（各ファイルの SHA-256 は run/manifest.json の `model_hashes`）
- プラグイン：BufferingStockOptimizerPlugin, CapacityOverridePlugin, HolidayCalendarPlugin
- 環境：python 3.12.3, platform Windows-11-10.0.26200-SP0, numpy 1.26.4, pandas 2.2.2, matplotlib 3.9.2

## コマンド（リポジトリ直下、Windows / PowerShell）

```powershell
git checkout 3481fc5b30ba88f8bb445d1ced888212b3221591
python -m tools.lovem_observe --model-dir data/sample/ev-thailand-2026 --out <新しいフォルダ> --q12 --se2-compare-sha 4ed2f14
```

- 同じ code_sha・同じ未 commit 差分（dirty_diff_hash）・同じモデル（model_hashes）なら、`manifest.json` の
  `created_at`・`timing_s` を除き、全ファイルがバイト単位で同じになる（段階 A 報告書 §7 で2回実行して確認）。
- `q12.json`：観測 OFF／ON の指紋と一致判定（Q12 の証拠）。
- `se2_case.json` の `comparison_run` は、`git archive 4ed2f14` を一時フォルダへ展開して同じプラグインで実行した結果。

## 照合の拠り所

- `DATA_DICTIONARY.md`（全ファイルの列・None と 0・ハッシュ正規化・identity_basis・証拠区分）
- `SHA256SUMS.txt`（このフォルダの全ファイル）
